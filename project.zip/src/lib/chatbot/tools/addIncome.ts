import { createRouteHandlerClient } from "@supabase/auth-helpers-nextjs";
import { cookies } from "next/headers";

export async function addIncome({
  name,
  amount,
}: {
  name: string;
  amount: string;
}) {
  const supabase = createRouteHandlerClient({ cookies });
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    console.error("❌ No user session found");
    return "⚠️ Please sign in to add income.";
  }

  const parsedAmount = parseFloat(amount);
  if (isNaN(parsedAmount) || parsedAmount <= 0) {
    return `⚠️ Invalid income amount: "${amount}".`;
  }

  const { data, error } = await supabase
    .from("incomes")
    .insert({
      user_id: user.id,
      name,
      amount: parsedAmount,
      date: new Date().toISOString(),
    })
    .select();

  if (error) {
    console.error("❌ Supabase income insert error:", error);
    return `❌ Failed to save income: ${error.message}`;
  }

  return `✅ Income "${name}" of ₹${parsedAmount} recorded.`;
}
