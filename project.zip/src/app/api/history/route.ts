// /app/api/history/route.ts or route.js
import { createRouteHandlerClient } from "@supabase/auth-helpers-nextjs";
import { cookies as getCookies } from "next/headers";
import { NextResponse } from "next/server";

export async function GET() {
  console.log("upar wala");

  const cookieStore = getCookies(); // ✅ get the cookie store
  const supabase = createRouteHandlerClient({ cookies: cookieStore }); // ✅ pass cookie store

  const {
    data: { user },
    error: userError,
  } = await supabase.auth.getUser();

  console.log("user", user);

  if (!user || userError) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { data: income, error: incomeError } = await supabase
    .from("incomes")
    .select("*")
    .eq("user_id", user.id);

  const { data: expenses, error: expenseError } = await supabase
    .from("expenses")
    .select("*")
    .eq("user_id", user.id);

  if (incomeError || expenseError) {
    return NextResponse.json(
      {
        income: income || [],
        expenses: expenses || [],
        error: incomeError?.message || expenseError?.message,
      },
      { status: 500 }
    );
  }

  return NextResponse.json({
    income,
    expenses: expenses.sort(
      (a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()
    ),
  });
}
